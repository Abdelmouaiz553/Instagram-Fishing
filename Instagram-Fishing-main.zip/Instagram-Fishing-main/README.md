# Instagram Fishing

How to Use it :-

Step 1:- Download the repositary via Link:- https://github.com/COxRIPMIZO/Instagram-Fishing.git

Step 2:- Extract the zip file in your desire folder and run the index.html.

Prerequisites :- 
1) XAMPP Server.
2) Ngrok Srvice or you can also use others tunnel services that u want.




--------------------------------------------- Happy Learning 😊😊👍👍---------------------------------------

---------------------------------------------      KHONSHU(Vishal)    ----------------------------------------

----------------------------------------------- Please Use This application Just for Educational Purpose. -------------------------------------------

